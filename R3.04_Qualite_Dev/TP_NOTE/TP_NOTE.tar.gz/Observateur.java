public interface Observateur {

    void notifier(String message);
}
