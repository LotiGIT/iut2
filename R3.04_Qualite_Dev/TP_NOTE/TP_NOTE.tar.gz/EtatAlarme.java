public interface EtatAlarme {
    public void armee(Alarme a);
    public void desarmee(Alarme a);
    public void retenir(Alarme a);
}
